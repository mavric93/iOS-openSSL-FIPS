#!/usr/local/bin/perl

while (<>)
	{
	print
	last if (/^# DO NOT DELETE THIS LINE/);
	}
